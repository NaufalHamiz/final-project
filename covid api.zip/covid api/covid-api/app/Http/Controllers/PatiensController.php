<?php

namespace App\Http\Controllers;

use App\Models\Patiens;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class PatiensController extends Controller
{
    # membuat method index
    public function index()
    {
        # menggunakan model Student untuk select data
        $patiens = Patiens::all();

        $data = [
            'message' => 'Get all resource',
            'data' => $patiens
        ];

        # mengirim data (json) dan kode 200
        return response()->json($data, 200);
    }

    # membuat method store
    public function store(Request $request)
    {
        $validateData = $request->validate([
            'name' => 'required',
            'phone' => 'required | numeric',
            'address' => 'required',
            'status' => 'required',
            'in_date_at' => 'required | date',
            'out_date_at' => 'nullable'

        ]);
        # menangkap data request
        $patiens = Patiens::create($validateData);

        $data = [
            'message' => 'Patiens is created succesfully',
            'data' => $patiens,
        ];

        // mengembalikan data (json) dan kode 201
        return response()->json($data, 201);
    }

    function show($id)
    {
        $patiens = Patiens::find($id);

        $data = [
            'message' => "Get Detail Patiens",
            'data' => $patiens
        ];

        return response()->json($data, 200);
    }

    # membuat method update
    public function update(Request $request, $id)
    {
        # cari id student yang ingin diupdate
        $patiens = Patiens::find($id);

        if ($patiens) {
            # menangkap data request
            $input = [
                'name' => $request->name ?? $patiens->name,
                'phone' => $request->phone ?? $patiens->phone,
                'address' => $request->address ?? $patiens->address,
                'status' => $request->status ?? $patiens->status,
                'in_date_at' => $request->in_date_at ?? $patiens->in_date_at,
                'out_date_at' => $request->out_date_at ?? $patiens->out_date_at
            ];

            # melakukan update data
            $patiens->update($input);

            $data = [
                'message' => 'Patiens is updated',
                'data' => $patiens
            ];

            # mengembalikan data (json) dan kode 200
            return response()->json($data, 200);
        } else {
            $data = [
                'message' => 'Patiens not found'
            ];

            return response()->json($data, 404);
        }
    }

    # membuat method destroy
    public function destroy($id)
    {
        # cari id student yang ingin dihapus
        $patiens = Patiens::find($id);

        if ($patiens) {
            # hapus student tersebut
            $patiens->delete();

            $data = [
                'message' => 'Patiens is deleted'
            ];

            # mengembalikan data (json) dan kode 200
            return response()->json($data, 200);
        } else {
            $data = [
                'message' => 'Patiens not found'
            ];

            return response()->json($data, 404);
        }
    }

    # membuat method search
    function search($name)
    {
        $patiens = Patiens::where('name', 'LIKE', "%$name%")->get();

        if (count($patiens) > 0) {
            $data = [
                'message' => "Get searched resource",
                'data' => $patiens
            ];
            return response()->json($data, 200);
        } else {
            $data = [
                'message' => "Resource not found"
            ];
            return response()->json($data, 404);
        }
    }

    # membuat method positive
    function positive()
    {
        return $this->search_by_status('positive');
    }

    # membuat method recovered
    function recovered()
    {
        return $this->search_by_status('recovered');
    }

    # membuat method dead
    function dead()
    {
        return $this->search_by_status('dead');
    }
}
