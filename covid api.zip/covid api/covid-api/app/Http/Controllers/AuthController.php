<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        /**
         *  Fitur Register
         * Ambil input nama, email, dan password
         * Input datanya ke database menggunakan user model
         */

        $input = [
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password)
        ];

        $user = User::create($input);

        $data = [
            'massage' => 'Register is successfuly'
        ];

        return response()->json($data, 200);
    }

    public function login(Request $request)
    {
        /**
         * Fitur login
         * Ambil input email dan password dari user
         * Ambil input email dan password dari database berdasarkan email
         * Bandingkan data input user dan data dari database
         */

        $input = [
            'email' => $request->email,
            'password' => $request->password
        ];

        $user = User::where('email', $input['email'])->first();

        if (Auth::attempt($input)) {
            /**Cara Manual-> ($input['email'] = $user->email && Hash::check($input['password'], )) {
             */
            $token = $user->createToken('auth_token');

            $data = [
                'massage' => 'Login is successfully',
                'token' => $token->plainTextToken
            ];

            return response()->json($data, 200);
        } else {
            $data = [
                'massage' => 'login is invalid'
            ];

            return response()->json($data, 401);
        }
    }
}
