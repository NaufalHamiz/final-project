<?php

use App\Http\Controllers\AuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PatiensController;
use App\Models\Patiens;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware(['auth:sanctum'])->group(function () {

    # Method GET All Resource, route /students
    Route::get("/patiens", [PatiensController::class, 'index']);

    # Get detail resource
    Route::get("/patiens/{id}", [PatiensController::class, 'show']);

    # Method POST, route /students
    Route::post("/patiens", [PatiensController::class, 'store']);

    # Method PUT, route /students
    Route::put("/patiens/{id}", [PatiensController::class, 'update']);

    # Method DELETE, route /students
    Route::delete("/patiens/{id}", [PatiensController::class, 'destroy']);
    # Method search 
    Route::get('/patiens/search/{name}', [PatiensController::class, 'search']);
    # Method Positive
    Route::get("/patiens/positive", [PatiensController::class, 'positive']);
    // get recovered resource
    Route::get("/patiens/recovered", [PatiensController::class, 'recovered']);
    // get dead resource
    Route::get("/patiens/dead", [PatiensController::class, 'dead']);
});

#Endpoint Register dan Login
Route::post("patiens/register", [AuthController::class, 'register']);
Route::post("patiens/login", [AuthController::class, 'login']);
